CREATE PROCEDURE ReadAllClientLight()
  BEGIN
    SELECT UuidFromBin(`id`) as 'id', `email`, `first_name`, `last_name` FROM `ClientProfile`;
  END;

