CREATE PROCEDURE DeleteClientProfile(IN client_id INT)
  BEGIN
    SELECT count(*) as `affected_count` FROM `ClientProfile` WHERE `id` = `client_id`;
    DELETE FROM `ClientProfile` WHERE `id` = `client_id`;
  END;

