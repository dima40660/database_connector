CREATE PROCEDURE CreateClientProfile(IN email              VARCHAR(100), IN first_name VARCHAR(100),
                                     IN last_name          VARCHAR(100), IN date_of_birth INT, IN address VARCHAR(100),
                                     IN postcode           VARCHAR(100), IN mobile VARCHAR(100),
                                     IN telephone          VARCHAR(100), IN nino VARCHAR(100),
                                     IN residency          VARCHAR(100), IN domiciled VARCHAR(100),
                                     IN marital_status     INT, IN partner_first_name VARCHAR(100),
                                     IN partner_last_name  VARCHAR(100), IN partner_residency VARCHAR(100),
                                     IN partner_domiciled  VARCHAR(100), IN children MEDIUMTEXT)
  BEGIN
    INSERT INTO `ClientProfile` (`id`, `email`, `first_name`, `last_name`, `date_of_birth`, `address`, `postcode`, `mobile`, `telephone`, `nino`, `residency`, `domiciled`, `marital_status`, `partner_first_name`, `partner_last_name`, `partner_residency`, `partner_domiciled`, `children`)
    VALUES (UuidToBin(UUID()), `email`, `first_name`, `last_name`, `date_of_birth`, `address`, `postcode`, `mobile`, `telephone`, `nino`, `residency`, `domiciled`, `marital_status`, `partner_first_name`, `partner_last_name`, `partner_residency`, `partner_domiciled`, `children`);
    SELECT LAST_INSERT_ID() as `created_id`;
  END;

