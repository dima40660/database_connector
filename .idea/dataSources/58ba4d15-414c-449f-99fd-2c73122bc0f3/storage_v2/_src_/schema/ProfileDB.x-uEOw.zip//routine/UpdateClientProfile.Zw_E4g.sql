CREATE PROCEDURE UpdateClientProfile(IN client_id          VARCHAR(36), IN email VARCHAR(100),
                                     IN first_name         VARCHAR(100), IN last_name VARCHAR(100),
                                     IN date_of_birth      INT, IN address VARCHAR(100), IN postcode VARCHAR(100),
                                     IN mobile             VARCHAR(100), IN telephone VARCHAR(100),
                                     IN nino               VARCHAR(100), IN residency VARCHAR(100),
                                     IN domiciled          VARCHAR(100), IN marital_status INT,
                                     IN partner_first_name VARCHAR(100), IN partner_last_name VARCHAR(100),
                                     IN partner_residency  VARCHAR(100), IN partner_domiciled VARCHAR(100),
                                     IN children           MEDIUMTEXT)
  BEGIN
    UPDATE `ClientProfile`
    SET
      `email` = `email`,
      `first_name` = `first_name`,
      `last_name` = `last_name`,
      `date_of_birth` = `date_of_birth`,
      `address` = `address`,
      `postcode` = `postcode`,
      `mobile` = `mobile`,
      `telephone` = `telephone`,
      `nino` = `nino`,
      `residency` = `residency`,
      `domiciled` = `domiciled`,
      `marital_status` = `marital_status`,
      `partner_first_name` = `partner_first_name`,
      `partner_last_name` = `partner_last_name`,
      `partner_residency` = `partner_residency`,
      `partner_domiciled` = `partner_domiciled`,
      `children` = `children`
    WHERE `id` = UuidToBin(`client_id`);
    SELECT count(*) as `affected_count` FROM `ClientProfile` WHERE `id` = UuidToBin(`client_id`);
  END;

