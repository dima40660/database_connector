CREATE PROCEDURE ReadClientProfile(IN client_id VARCHAR(36))
  BEGIN
    SELECT UuidFromBin(`id`) as `id`, `email`, `first_name`, `last_name` , `date_of_birth`, `address`, `postcode`, `mobile`, `telephone`, `nino`, `residency`, `domiciled`, `marital_status`, `partner_first_name`, `partner_last_name`, `partner_residency`, `partner_domiciled`, `children`
    FROM `ClientProfile` WHERE `id` = UuidToBin(`client_id`);
  END;

