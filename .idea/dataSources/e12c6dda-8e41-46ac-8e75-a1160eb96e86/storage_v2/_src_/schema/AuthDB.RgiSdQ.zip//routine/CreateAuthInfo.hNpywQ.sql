CREATE PROCEDURE CreateAuthInfo(IN client_id       VARCHAR(36), IN client_email VARCHAR(100),
                                IN client_password VARBINARY(64))
  BEGIN
  INSERT `AuthInfo` (`id`, `token`, `email`, `password`) VALUES (UuidToBin(`client_id`), NULL, `client_email`, `client_password`);
END;

