CREATE PROCEDURE CheckEmailPassword(IN client_email VARCHAR(100), IN client_password VARCHAR(100))
  BEGIN
    SELECT if((`client_password` = `password`), UuidFromBin(`id`), -1) as `id` FROM `AuthInfo` WHERE `email` = `client_email`;
  END;

