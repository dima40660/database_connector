CREATE PROCEDURE DeleteAuthToken(IN client_id VARCHAR(36))
  BEGIN
  SELECT count(*) as `affected_count` FROM `AuthInfo` WHERE `id` = UuidToBin(`client_id`);
  UPDATE `AuthInfo` SET `token` = NULL WHERE `id` = UuidToBin(`client_id`);
END;

