CREATE PROCEDURE CheckAuthToken(IN client_id VARCHAR(36), IN auth_token VARCHAR(100))
  BEGIN
  SELECT `auth_token` = `token` as `is_valid_token` FROM `AuthInfo` WHERE `id` = UuidToBin(`client_id`);
END;

